<?php
//masukan config token yg terdapat pada link di packet captur
// jangan hapus tanda kutip(" ") 

$access_token = "c5a65f71-ecbe-46a0-b011-a8125ae04878";

// kamu bisa membuat banyak config untuk beberapa akun.
